<?php
namespace Priyank\Testimonials\Controller\Adminhtml\Testimonials;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\App\Filesystem\DirectoryList;

class ExportCsv extends Action
{
    protected $fileFactory;
    protected $csvProcessor;

    public function __construct(
        Context $context,
        FileFactory $fileFactory,
        \Magento\Framework\File\Csv $csvProcessor
    ) {
        $this->fileFactory = $fileFactory;
        $this->csvProcessor = $csvProcessor;
        parent::__construct($context);
    }

    public function execute()
    {
        $fileName = 'testimonials_' . date('Y-m-d_H-i-s') . '.csv';
        $filesystem = $this->_objectManager->get(\Magento\Framework\Filesystem::class);
        $varDir = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
        $varDir->create('');
        $filePath = $varDir->getAbsolutePath($fileName);
        $this->csvProcessor->setDelimiter(',')->setEnclosure('"');
        $collection = $this->_objectManager->create(
            \Priyank\Testimonials\Model\ResourceModel\Testimonials\Collection::class
        );
        $header = ['company_name','name','message','post','profile_pic','status','created_at','updated_at'];
        $rows = array_map(function ($row) use ($header) {
            return array_values(array_intersect_key($row, array_flip($header)));
        }, $collection->getData());
        $data = array_merge([$header], $rows);
        $this->csvProcessor->saveData($filePath, $data);

        return $this->fileFactory->create(
            $fileName,
            [
                'type'  => 'filename',
                'value' => $fileName,
                'rm'    => true
            ],
            DirectoryList::VAR_DIR,
            'text/csv'
        );
    }


    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Priyank_Testimonials::testimonial');
    }
}

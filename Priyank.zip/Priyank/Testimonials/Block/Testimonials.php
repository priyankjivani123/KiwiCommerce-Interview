<?php
namespace Priyank\Testimonials\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Priyank\Testimonials\Model\ResourceModel\Testimonials\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;

class Testimonials extends Template
{
    protected $collectionFactory;
    protected $storeManager;

    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        StoreManagerInterface $storeManager,
        array $data = []
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->storeManager = $storeManager;
        parent::__construct($context, $data);
    }

    /**
     * Get approved testimonials collection
     */
    public function getTestimonials()
    {
        $collection = $this->collectionFactory->create();
        $collection->addFieldToFilter('status', 1)
                   ->setOrder('created_at', 'DESC');
        return $collection;
    }

    /**
     * Get media URL for profile pictures
     */
    public function getMediaUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    }

    /**
     * Get profile picture URL
     */
    public function getProfilePicUrl($profilePic)
    {
        if ($profilePic) {
            return $this->getMediaUrl() . 'wysiwyg/helloworld/' . $profilePic;
        }
        return $this->getViewFileUrl('Priyank_Testimonials::images/default-avatar.png');
    }
}
